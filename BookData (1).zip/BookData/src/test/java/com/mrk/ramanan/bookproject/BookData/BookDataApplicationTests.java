package com.mrk.ramanan.bookproject.BookData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
