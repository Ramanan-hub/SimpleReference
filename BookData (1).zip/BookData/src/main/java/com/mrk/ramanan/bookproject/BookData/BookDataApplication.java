package com.mrk.ramanan.bookproject.BookData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookDataApplication.class, args);
	}

}
